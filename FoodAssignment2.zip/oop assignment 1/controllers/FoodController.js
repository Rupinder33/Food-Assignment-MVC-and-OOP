const FoodItem = require('../models/fooditem');

class FoodController {
    constructor() {
        this.foodItems = [];
    }

    addFoodItem(id, name, price, category, image) { // Add image parameter
        const newItem = new FoodItem(id, name, price, category, image); // Pass image
        this.foodItems.push(newItem.getFoodItem());
    }

    getFoodItems() {
        return this.foodItems;
    }

    getFoodItemById(id) {
        return this.foodItems.find(item => item.id === id);
    }

    // Method to update the price of a food item by its ID
    updatePriceById(id, newPrice) {
        const item = this.getFoodItemById(id);
        if (item) {
            item.price = newPrice;
            return true;
        } else {
            return false;
        }
    }
}

module.exports = FoodController;
