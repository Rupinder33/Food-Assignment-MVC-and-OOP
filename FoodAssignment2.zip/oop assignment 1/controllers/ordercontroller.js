const Order = require('../models/orders'); // Import the Order class

class OrderController {
    constructor() {
        this.orders = [];
    }

    createOrder(id) {
        const newOrder = new Order(id);
        this.orders.push(newOrder);
        return newOrder;
    }

    getOrderById(id) {
        return this.orders.find(order => order.id === id);
    }

    addItemToOrder(orderId, item) {
        const order = this.getOrderById(orderId);
        if (order) {
            order.addItem({ ...item, image: item.image });
        }
    }
    

    removeItemFromOrder(orderId, itemId) {
        const order = this.getOrderById(orderId);
        if (order) {
            order.removeItem(itemId);
        }
    }
}

module.exports = OrderController;
