class Order {
    constructor(id, items = [], totalAmount = 0) {
        this.id = id;
        this.items = items; // Array of FoodItem objects
        this.totalAmount = totalAmount;
    }

    addItem(item) {
        this.items.push(item);
        this.totalAmount += item.price;
    }

    removeItem(itemId) {
        const itemIndex = this.items.findIndex(item => item.id === itemId);
        if (itemIndex !== -1) {
            if (this.totalAmount > 0) {
                this.totalAmount -= this.items[itemIndex].price;
            } else {
                this.totalAmount = 0;
            }

            this.items.splice(itemIndex, 1);
        }
    }
}

module.exports = Order;
