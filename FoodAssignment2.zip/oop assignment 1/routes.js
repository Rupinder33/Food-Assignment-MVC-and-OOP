// routes.js
const express = require('express');
const router = express.Router();
const FoodController = require('./controllers/foodController');
const OrderController = require('./controllers/orderController');

const foodController = new FoodController();
const orderController = new OrderController();

// Initialize some food items with images
foodController.addFoodItem(1, 'Burger', 5.99, 'Fast Food', '../images/burger.jpg');
foodController.addFoodItem(2, 'Pizza', 8.99, 'Fast Food', '../images/pizza.jpg');
foodController.addFoodItem(3, 'Noodles', 12.99, 'Japanese', '../images/noodles.jpeg');
foodController.addFoodItem(4, 'Pasta', 10.99, 'Italian', '../images/pasta.jpeg');
foodController.addFoodItem(5, 'Samosa', 5.99, 'Indian', '../images/samosas.jpeg');
foodController.addFoodItem(6, 'Sandwich', 8.99, 'Italian', '../images/sandwich.jpeg');
foodController.addFoodItem(7, 'Spring rolls', 12.99, 'Chinese', '../images/sping roll.jpeg');
foodController.addFoodItem(8, 'Momos', 10.99, 'Italian', '../images/momos.jpeg');
foodController.addFoodItem(9, 'Vegetable roll', 5.99, 'Fast Food', '../images/roll.jpeg');
foodController.addFoodItem(10, 'Fries', 8.99, 'Fast Food', '../images/fries.jpeg');


// Create a default order
orderController.createOrder(1);

// Routes
router.get('/', (req, res) => {
    res.render('index');
});

router.get('/food', (req, res) => {
    const foodItems = foodController.getFoodItems();
    res.render('food', { foodItems });
});

router.get('/order/:id', (req, res) => {
    const order = orderController.getOrderById(parseInt(req.params.id));
    if (order) {
        res.render('order', { order });
    } else {
        res.status(404).send('Order not found');
    }
});

router.post('/order/:id/add', (req, res) => {
    const orderId = parseInt(req.params.id);
    const foodId = parseInt(req.body.foodId);
    const foodItem = foodController.getFoodItemById(foodId);
    const order = orderController.getOrderById(parseInt(orderId));
    if (foodItem) {
        orderController.addItemToOrder(orderId, foodItem);
        // res.redirect('/order/' + orderId);
        res.render('order', {
            pageTitle: 'Order food',
            path: '/order/' + orderId,
            orderId: orderId,
            order: order
        });
    } else {
        res.status(404).send('Food item not found');
    }
});


router.post('/order/remove', (req, res) => {
    const orderId = parseInt(req.body.orderId);
    const foodId = parseInt(req.body.foodId);
    const foodItem = foodController.getFoodItemById(foodId);
    const order = orderController.getOrderById(parseInt(orderId));
    if (foodItem) {
        orderController.removeItemFromOrder(orderId, foodId);
        res.render('order', {
            pageTitle: 'Order food',
            path: '/order/' + orderId,
            orderId: orderId,
            order: order
        });
    } else {
        res.status(404).send('Food item not found');
    }
});

router.post('/update-price', (req, res) => {
    const newprice = parseInt(req.body.newPrice);
    const foodId = parseInt(req.body.foodId);
    const foodItem = foodController.updatePriceById(foodId, newprice);
    if (foodItem) {
        res.send({ success: true, message: 'Price updated successfully' });
    } else {
        res.status(404).send('Food item not found');
    }
});


router.get('/food/search', (req, res) => {
    const query = req.query.query.toLowerCase(); // Get the search query and convert it to lowercase
    const searchResults = foodController
        .getFoodItems()
        .filter(item => item.name.toLowerCase().includes(query)); // Filter food items based on query

    res.render('food', { foodItems: searchResults }); // Reuse the food view to display search results
});



module.exports = router;
